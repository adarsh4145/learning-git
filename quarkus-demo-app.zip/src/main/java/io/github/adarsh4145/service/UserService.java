package io.github.adarsh4145.service;

import io.github.adarsh4145.entity.User;
import io.github.adarsh4145.secuirty.CustomAwareJWTAuthMechanism;
import io.quarkus.hibernate.reactive.panache.Panache;
import io.quarkus.hibernate.reactive.panache.common.runtime.ReactiveTransactional;
import io.smallrye.common.annotation.Blocking;
import io.smallrye.mutiny.Uni;
import org.jboss.logging.Logger;

import javax.annotation.security.RolesAllowed;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.context.control.ActivateRequestContext;
import javax.transaction.Transactional;
import java.util.List;

@ApplicationScoped
@ActivateRequestContext
public class UserService {
    private static final Logger LOG = Logger.getLogger(UserService.class);

    @Transactional
    public Uni<User> createUser(User user){
        return Panache.<User>withTransaction(user::persist)
                .map(user1 -> user1);
    }

    @RolesAllowed("Admin")
    public Uni<List<User>> getAllUsers(){
        LOG.info("getting all users");
        return User.listAll();
    }

    public Uni<User> getUserById(long id){

        return User.findById(id);
    }

    @Transactional
    @Blocking
    public Uni<User> getUserByName(String name){
        return User.find("name",name)
                .singleResult();
    }

    public Uni<Boolean> deleteUserById(long id){
        return User.deleteById(id);
    }

}
