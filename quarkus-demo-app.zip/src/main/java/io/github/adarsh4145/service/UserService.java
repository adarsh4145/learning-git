package io.github.adarsh4145.service;

import io.github.adarsh4145.entity.User;
import io.quarkus.hibernate.reactive.panache.Panache;
import io.quarkus.hibernate.reactive.panache.common.runtime.ReactiveTransactional;
import io.smallrye.mutiny.Uni;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.context.control.ActivateRequestContext;
import javax.transaction.Transactional;
import java.util.List;

@ApplicationScoped
@ActivateRequestContext
public class UserService {

    @Transactional
    public Uni<User> createUser(User user){
        return Panache.<User>withTransaction(user::persist)
                .map(user1 -> user1);
    }

    public Uni<List<User>> getAllUsers(){
        return User.listAll();
    }

    public Uni<User> getUserById(long id){

        return User.findById(id);
    }

    @Transactional
    public Uni<User> getUserByName(String name){
        return User.find("name",name)
                .singleResult();
    }

    public Uni<Boolean> deleteUserById(long id){
        return User.deleteById(id);
    }

}
