package io.github.adarsh4145.resource;

import java.security.Principal;
import java.time.Duration;
import java.util.Arrays;
import java.util.HashSet;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.transaction.Transactional;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.SecurityContext;

import io.quarkus.security.Authenticated;
import io.smallrye.jwt.algorithm.SignatureAlgorithm;
import io.smallrye.jwt.build.Jwt;
import org.eclipse.microprofile.jwt.Claims;
import org.eclipse.microprofile.jwt.JsonWebToken;

@Path("/secured")
@RequestScoped
public class TokenSecuredResource {

    @Inject
    JsonWebToken jwt;

    @GET()
    @Path("get-token/{name}")
    @PermitAll
    @Produces(MediaType.TEXT_PLAIN)
    @Transactional
    public String token(@Context SecurityContext ctx, @PathParam("name") String name) {
        return
                Jwt.issuer("https://example.com/issuer")
                        .upn("jdoe@quarkus.io")
                        //.groups(new HashSet<>(Arrays.asList("User", "Admin")))
                        .claim(Claims.birthdate.name(), "2001-07-13")
                        .claim(Claims.full_name.name(),name)
                        .expiresIn(Duration.ofDays(5))
                        .jws()
                        .algorithm(SignatureAlgorithm.HS256)
                        .signWithSecret("hellomynameisadarshhowareyouguysiamgood")
                ;
    }

    @GET()
    @Path("permit-all")
//    @Authenticated
    @Produces(MediaType.TEXT_PLAIN)
    @RolesAllowed("Admin")
    public String hello(@Context SecurityContext ctx) {

        return "validated";
    }
//
//
//
//    @GET
//    @Path("roles-allowed")
//    @RolesAllowed({ "User", "Admin" })
//    @Produces(MediaType.TEXT_PLAIN)
//    public String helloRolesAllowed(@Context SecurityContext ctx) {
//        System.out.println(jwt.getRawToken());
//        return getResponseString(ctx) + ", birthdate: " + jwt.getClaim("birthdate").toString();
//    }
//
//
//    private String getResponseString(SecurityContext ctx) {
//        String name;
//        if (ctx.getUserPrincipal() == null) {
//            name = "anonymous";
//        } else if (!ctx.getUserPrincipal().getName().equals(jwt.getName())) {
//            throw new InternalServerErrorException("Principal and JsonWebToken names do not match");
//        } else {
//            name = ctx.getUserPrincipal().getName();
//        }
//        return String.format("hello + %s,"
//                        + " isHttps: %s,"
//                        + " authScheme: %s,"
//                        + " hasJWT: %s",
//                name, ctx.isSecure(), ctx.getAuthenticationScheme(), hasJwt());
//    }
//
//    private boolean hasJwt() {
//        return jwt.getClaimNames() != null;
//    }
}