package io.github.adarsh4145.resource;

import io.github.adarsh4145.entity.User;
import io.github.adarsh4145.service.UserService;
import io.smallrye.mutiny.Uni;

import javax.inject.Inject;
import javax.transaction.Transactional;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.URI;


@Path("/users")
public class UserResource {

    @Inject
    UserService userService;

    @GET
//    @Produces(MediaType.APPLICATION_JSON)
    public Uni<Response> getAllUsers() {

        return userService.getAllUsers()
                .map(users-> Response.ok(users).build());
    }

    @GET
    @Path("{id}")
//    @Produces(MediaType.APPLICATION_JSON)
    public Uni<Response> getUserById(@PathParam("id") Long id){
        return userService.getUserById(id)
                .map(user->Response.ok(user).build());
    }

    @GET
    @Path("name/{name}")
//    @Produces(MediaType.APPLICATION_JSON)
    public Uni<Response> getUserByName(@PathParam("name")String name){
        return userService.getUserByName(name)
                .map(user-> Response.ok(user).build());
    }

    @POST
    @Transactional
    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
    public Uni<Response> createUser(User user){
        return userService.createUser(user).map(user1 ->Response.created(URI.create("/users/"+user1.getId())).build());
       }

    @DELETE
    @Path("{id}")
    public Uni<Response> deleteById(@PathParam("id") Long id){
        return userService.deleteUserById(id).map(result -> Response.noContent().build());
    }




}