package io.github.adarsh4145.secuirty;

import io.github.adarsh4145.entity.User;
import io.github.adarsh4145.service.UserService;
import io.quarkus.arc.Priority;
import io.quarkus.security.identity.IdentityProviderManager;
import io.quarkus.security.identity.SecurityIdentity;
import io.quarkus.security.identity.request.AuthenticationRequest;
import io.quarkus.smallrye.jwt.runtime.auth.JWTAuthMechanism;
import io.quarkus.vertx.http.runtime.security.ChallengeData;
import io.quarkus.vertx.http.runtime.security.HttpAuthenticationMechanism;
import io.smallrye.mutiny.Uni;
import io.vertx.ext.web.RoutingContext;
import org.jboss.logging.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Alternative;
import javax.inject.Inject;
import javax.transaction.Transactional;
import java.util.Base64;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

@Alternative
@Priority(1)
@ApplicationScoped
public class CustomAwareJWTAuthMechanism implements HttpAuthenticationMechanism {

    private static final Logger LOG = Logger.getLogger(CustomAwareJWTAuthMechanism.class);

    @Inject
    JWTAuthMechanism delegate;

    @Inject
    UserService userService;

    @Transactional
    @Override
    public Uni<SecurityIdentity> authenticate(RoutingContext context, IdentityProviderManager identityProviderManager) {
        // do some custom action and delegate

        String token = context.request().headers().get("x-api-token");
        LOG.info("path: " + context.request().path());

        if (token == null) {
            LOG.info("x-api-token header not present!");
            if(context.request().path().startsWith("/secured/get-token/")){
                LOG.info("request for getting token, returning token in response");
                return delegate.authenticate(context, identityProviderManager);
            }
            context.response().setStatusCode(403).setStatusMessage("Please add x-api-token").send();

            return delegate.authenticate(context, identityProviderManager);
        }

        LOG.info("token: " + token);
        String[] parts = token.split("\\.");
        JSONObject header = new JSONObject(decode(parts[0]));
        JSONObject payload = new JSONObject(decode(parts[1]));
        String signature = decode(parts[2]);

        LOG.info("header: " + header);
        LOG.info("payload: " + payload);
        LOG.info("signature: " + signature);

        LOG.info("doing some validation here, say issuer etc ...");

        if(!validateToken(header,payload,signature)){
            LOG.info("token validation failed, unauthorized request!");
            context.response().setStatusCode(403).send();
            return delegate.authenticate(context, identityProviderManager);
        }

        JSONArray roles = payload.getJSONArray("groups");//full_name
        Set<String> roleSet = new HashSet<>();
        roles.forEach(role -> {
            LOG.info("roles found: " + role);
            roleSet.add((String) role);
        });
        String name = payload.getString("full_name");

        LOG.info("name : " + name);

        Uni<User> userUni = userService.getUserByName(name)
                .onFailure().recoverWithItem(() -> new User(0L,name));


        AtomicInteger num =  new AtomicInteger();
        num.set(1);

        userUni.subscribe().with(user -> {
            if(user.getId()==0){
                LOG.info("user not in db: " + name);
                num.set(2);
                LOG.info("calling create user: " + name);

                User userToAdd = new User();
                userToAdd.setName(name);

                userService.createUser(userToAdd)
                        .subscribe().with(user1 -> {
                            LOG.info("saved user in db: " + name);
                        });
            }
            else{
                LOG.info("user in db: " + name);
                num.set(1);
            }
            LOG.info("num: " + num.get());
        });

        return delegate.authenticate(context, identityProviderManager);
    }

    private boolean validateToken(JSONObject header, JSONObject payload, String signature) {
        return true;
    }

    @Override
    public Uni<ChallengeData> getChallenge(RoutingContext context) {
        return delegate.getChallenge(context);
    }

    @Override
    public Set<Class<? extends AuthenticationRequest>> getCredentialTypes() {
        return delegate.getCredentialTypes();
    }

    private static String decode(String encodedString) {
        return new String(Base64.getUrlDecoder().decode(encodedString));
    }
}

/*userService.getUserByName(name)
                .subscribe().with(user -> {
                    LOG.info("user present with name : " + user.getName());
                })
                .onFailure().invoke((failure) -> {
                    LOG.info("user not present by name:");
//                    userService.createUser(new User(0L,name))
//                            .onFailure().invoke(failure -> {
//                                LOG.info("error: "+failure.getMessage());
//                            })
//                            .subscribe().with( user -> {
//                                LOG.info("new user created : " + user.getName());
//                            });
                })
                .subscribe().with(user -> {
                    LOG.info("user present with name : " + user.getName());
                });*/