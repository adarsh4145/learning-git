package io.github.adarsh4145.secuirty;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import javax.annotation.Priority;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Alternative;
import javax.inject.Inject;

import io.github.adarsh4145.entity.User;
import io.github.adarsh4145.service.UserService;
import io.smallrye.mutiny.Uni;
import org.jboss.logging.Logger;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwt.consumer.InvalidJwtException;
import io.smallrye.jwt.auth.principal.DefaultJWTCallerPrincipal;
import io.smallrye.jwt.auth.principal.JWTAuthContextInfo;
import io.smallrye.jwt.auth.principal.JWTCallerPrincipal;
import io.smallrye.jwt.auth.principal.JWTCallerPrincipalFactory;
import io.smallrye.jwt.auth.principal.ParseException;
import org.json.JSONObject;

@ApplicationScoped
@Alternative
@Priority(2)
public class TestJWTCallerPrincipalFactory extends JWTCallerPrincipalFactory {
    private static final Logger LOG = Logger.getLogger(TestJWTCallerPrincipalFactory.class);

    @Inject
    UserService userService;

    @Override
    public JWTCallerPrincipal parse(String token, JWTAuthContextInfo authContextInfo) throws ParseException {
        try {
            // Token has already been verified, parse the token claims only
            LOG.info("parsing token");
            String json = new String(Base64.getUrlDecoder().decode(token.split("\\.")[1]), StandardCharsets.UTF_8);

            String[] parts = token.split("\\.");
            JSONObject header = new JSONObject(decode(parts[0]));
            JSONObject payload = new JSONObject(decode(parts[1]));
            String signature = decode(parts[2]);

            LOG.info("header: " + header);
            LOG.info("payload: " + payload);
            LOG.info("signature: " + signature);


            LOG.info("doing some validation here, say issuer etc ...");

            String name = payload.getString("full_name");

            LOG.info("name : " + name);


            Uni<User> userUni = userService.getUserByName(name)
                    .onFailure().recoverWithItem(() -> new User(0L,name));


            AtomicInteger num =  new AtomicInteger();
            num.set(1);

            userUni.subscribe().with(user -> {
                if(user.getId()==0){
                    LOG.info("user not in db: " + name);
                    num.set(2);
                    LOG.info("calling create user: " + name);

                    User userToAdd = new User();
                    userToAdd.setName(name);

                    userService.createUser(userToAdd)
                            .subscribe().with(user1 -> {
                                LOG.info("saved user in db: " + name);
                            });
                }
                else{
                    LOG.info("user in db: " + name);
                    num.set(1);
                }
                LOG.info("num: " + num.get());
            });

            payload.put("groups", Set.of("Admin","User"));

            LOG.info("new payload: "+payload);



            String newPayload = encode(payload.toString());

            LOG.info("newPayload: " + newPayload);


            String newToken = "Bearer " + parts[0] +"."+ newPayload +"."+parts[2];

            LOG.info("newToken: " + newToken);
            LOG.info("json: "+json);


            LOG.info("token: "+token);




            return new DefaultJWTCallerPrincipal(JwtClaims.parse(payload.toString()));
        } catch (InvalidJwtException ex) {
            throw new ParseException(ex.getMessage());
        }
    }



    private static String decode(String encodedString) {
        return new String(Base64.getUrlDecoder().decode(encodedString));
    }

    private static String encode(String decodedString) {
        return Base64.getUrlEncoder().encodeToString(decodedString.getBytes(StandardCharsets.UTF_8)).replace("=","");
    }

}