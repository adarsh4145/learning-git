package io.github.adarsh4145.exception;

import org.jboss.resteasy.reactive.RestResponse;
import org.jboss.resteasy.reactive.server.ServerExceptionMapper;

import javax.persistence.NoResultException;
import javax.ws.rs.core.Response;

public class ExceptionMappers {
    @ServerExceptionMapper
    public RestResponse<String> mapException(NoResultException ex) {
        return RestResponse.status(Response.Status.NOT_FOUND, ex.getMessage());
    }
}