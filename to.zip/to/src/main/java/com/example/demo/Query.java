package com.example.demo;

import graphql.kickstart.tools.GraphQLQueryResolver;

import java.util.List;

class Query implements GraphQLQueryResolver {



    public List<Book> books() {
        return null;
    }
}