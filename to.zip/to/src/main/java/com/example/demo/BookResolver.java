package com.example.demo;

import graphql.kickstart.tools.GraphQLResolver;

class BookResolver implements GraphQLResolver<Book> /* This class is a resolver for the Book "Data Class" */ {



    public Author author(Book book) {
        return null;
    }
}
