package com.example.demo;

import com.google.common.base.Charsets;
import graphql.GraphQL;
import graphql.kickstart.tools.SchemaParser;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.websocket.javax.server.config.JavaxWebSocketServletContainerInitializer;


import javax.websocket.server.ServerEndpointConfig;
import java.io.IOException;
import java.net.URL;

//@SpringBootApplication
public class DemoApplication {

    public static void main(String[] args) throws Exception {
//        SpringApplication.run(DemoApplication.class, args);
        initCode();
    }


//    @PostConstruct
    public static  void initCode () throws Exception {
        var server = new Server();
        var connector = new ServerConnector(server);
        connector.setPort(8000);
        server.addConnector(connector);

        var context = new ServletContextHandler(ServletContextHandler.SESSIONS);
        context.setContextPath("/");
//        context.addS
        context.addServlet(HelloServlet.class.getName(), "/graphql");
        server.setHandler(context);


        JavaxWebSocketServletContainerInitializer.configure(
                context,
                (servletContext, serverContainer) ->
                        serverContainer.addEndpoint(
                                ServerEndpointConfig.Builder.create(SubscriptionEndpoint.class, "/subscriptions")
                                        .configurator(new GraphQLWSEndpointConfigurer())
                                        .build()));

        server.setHandler(context);

        server.start();
        server.dump(System.err);
        server.join();
    }

}

