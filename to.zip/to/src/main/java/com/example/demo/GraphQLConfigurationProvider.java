package com.example.demo;

import com.google.common.base.Charsets;
import graphql.GraphQL;
import graphql.execution.AsyncExecutionStrategy;
import graphql.execution.SubscriptionExecutionStrategy;
import graphql.kickstart.execution.GraphQLQueryInvoker;
import graphql.kickstart.execution.config.DefaultExecutionStrategyProvider;
import graphql.kickstart.servlet.GraphQLConfiguration;
import graphql.kickstart.tools.SchemaParser;
import graphql.schema.DataFetcher;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.TypeDefinitionRegistry;
import org.reactivestreams.Publisher;
import reactor.core.publisher.Flux;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.time.Duration;

class GraphQLConfigurationProvider {

    private static GraphQLConfigurationProvider instance;

    private final GraphQLConfiguration configuration;

    private GraphQLConfigurationProvider() {
        configuration =
                GraphQLConfiguration.with(createSchema())
                        .with(
                                GraphQLQueryInvoker.newBuilder()
                                        .withExecutionStrategyProvider(
                                                new DefaultExecutionStrategyProvider(
                                                        new AsyncExecutionStrategy(),
                                                        null,
                                                        new SubscriptionExecutionStrategy()))
                                        .build())
                        .build();
    }

    static GraphQLConfigurationProvider getInstance() {
        if (instance == null) {
            instance = new GraphQLConfigurationProvider();
        }
        return instance;
    }

    GraphQLConfiguration getConfiguration() {
        return configuration;
    }


    private GraphQLSchema createSchema() {
//        TypeDefinitionRegistry typeRegistry = new SchemaParser().parse(loadSchemaFile());
//
//        RuntimeWiring runtimeWiring =
//                newRuntimeWiring()
//                        .type(newTypeWiring("Query").dataFetcher("hello", new StaticDataFetcher("world")))
//                        .type(newTypeWiring("Subscription").dataFetcher("ping", pingFetcher()))
//                        .build();
//
//        SchemaGenerator schemaGenerator = new SchemaGenerator();
//        return schemaGenerator.makeExecutableSchema(typeRegistry, runtimeWiring);
        URL url = com.google.common.io.Resources.getResource("schema.graphqls");

        try {
            var sdl = com.google.common.io.Resources.toString(url, Charsets.UTF_8);
            var x = SchemaParser.newParser()
                    .schemaString(sdl)
                    // ...
                    .resolvers(new Query(), new BookResolver())
                    .build().makeExecutableSchema();

            GraphQL graphQL = GraphQL.newGraphQL(x).build();

            System.out.println(sdl);
            return graphQL.getGraphQLSchema();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
            return null;
        }

    }

    private DataFetcher<Publisher<String>> pingFetcher() {
        return environment -> Flux.just("pong").repeat().delayElements(Duration.ofSeconds(1));
    }

//    private Reader loadSchemaFile() {
//        InputStream stream = getClass().getClassLoader().getResourceAsStream("schema.graphqls");
//        return new InputStreamReader(stream);
//    }
}